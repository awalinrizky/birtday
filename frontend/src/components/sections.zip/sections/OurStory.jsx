import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { story } from "../../data/story.js";
import SectionTitle from "../ui/SectionTitle";
import axios from "axios";
import Container from "../ui/Container";

const axiosInstance = axios.create({
  baseURL: "http://localhost:5000/api",
  headers: { "Content-Type": "application/json" },
});

export default function OurStory() {
  const [timelines, setTimelines] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchTimelines = async () => {
      try {
        const response = await axiosInstance.get("/timelines");
        // Pastikan kita mengambil array data dari response backend
        setTimelines(response.data.data || []);
      } catch (error) {
        console.error("Gagal mengambil data timeline:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTimelines();
  }, []);

  // Format Date ke gaya estetik (misal: "July 2, 2024")
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "long", day: "numeric" };
    return new Date(dateString).toLocaleDateString("en-US", options);
  };

  return (
    <Container>
      <SectionTitle
        eyebrow="Our Story"
        title="Captured Moments"
        description="Every photo tells a story, every memory lasts forever."
      />

      {/* Tampilan saat masih mengambil data dari Database */}
      {isLoading ? (
        <div className="text-center text-mutedText font-sans animate-pulse">
          Gathering our memories...
        </div>
      ) : timelines.length === 0 ? (
        /* Tampilan jika lo belum masukin data apapun di Admin */
        <div className="text-center text-mutedText font-sans italic">
          The beginning of our journey is yet to be written.
        </div>
      ) : (
        /* Render Data Asli */
        <div className="space-y-12">
          {timelines.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.8 }}
              className="flex gap-4 md:gap-8 items-start"
            >
              {/* Tanggal */}
              <div className="font-serif text-roseGold mt-1 whitespace-nowrap min-w-[100px] text-right text-sm md:text-base">
                {formatDate(item.event_date)}
              </div>

              {/* Konten Timeline & Garis */}
              <div className="border-l border-beige pl-6 pb-8 relative">
                {/* Lingkaran kecil di garis timeline */}
                <div className="absolute w-3 h-3 bg-warmWhite border-2 border-roseGold rounded-full -left-[7px] top-1.5"></div>

                <h3 className="text-xl text-darkText font-medium mb-2">
                  {item.title}
                </h3>
                <p className="font-sans text-mutedText text-sm leading-relaxed whitespace-pre-wrap">
                  {item.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </Container>
  );
}
